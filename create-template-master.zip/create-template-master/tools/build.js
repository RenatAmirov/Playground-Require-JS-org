{
    "appDir": "../www",
    "mainConfigFile": "../www/app.js",
    "dir": "../www-built",
    // List the modules that will be optimized.
    "modules": [
        {
            // module names are relative to baseUrl
            "name": "app"
        }
    ]
}
